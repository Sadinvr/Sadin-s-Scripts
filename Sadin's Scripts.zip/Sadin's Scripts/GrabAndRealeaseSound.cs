using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class GrabAndRealeaseSound : MonoBehaviour
{
    public AudioClip grabSound;
    public AudioClip releaseSound;

    private XRGrabInteractable grabInteractable;
    private AudioSource audioSource;

    void Start()
    {
        grabInteractable = GetComponent<XRGrabInteractable>();

        audioSource = GetComponent<AudioSource>();

        if (audioSource == null)
        {
            Debug.LogError("AudioSource component not found.");
            return;
        }

        grabInteractable.onSelectEntered.AddListener(PlayGrabSound);
        grabInteractable.onSelectExited.AddListener(PlayReleaseSound);
    }

    void PlayGrabSound(XRBaseInteractor interactor)
    {
        if (grabSound != null && !audioSource.isPlaying)
        {
            audioSource.clip = grabSound;
            audioSource.Play();
        }
    }

    void PlayReleaseSound(XRBaseInteractor interactor)
    {
        if (releaseSound != null && !audioSource.isPlaying)
        {
            audioSource.clip = releaseSound;
            audioSource.Play();
        }
    }
}
