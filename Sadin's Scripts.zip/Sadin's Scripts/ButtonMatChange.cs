using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonMatChange : MonoBehaviour
{
    public Material touchedMaterial;
    public Material originalMaterial;
    private Renderer renderer;

    void Start()
    {
        renderer = GetComponent<Renderer>();
        originalMaterial = renderer.material;
    }

    void OnTriggerEnter(Collider other)
    {
        renderer.material = touchedMaterial;
    }

    void OnTriggerExit(Collider other)
    {
        renderer.material = originalMaterial;
    }
}
