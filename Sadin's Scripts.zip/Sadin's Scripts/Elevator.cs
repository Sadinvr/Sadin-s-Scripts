using System.Collections.Generic;
using System.Collections;
using UnityEngine;
using Photon.Pun;

public class Elevator : MonoBehaviour
{
    [Header("CREDITS TO SADIN FOR MAKING THE SCRIPT")]
    public Transform elevatorTransform;
    public Transform goToTransform;

    public float speed = 5f;

    void Update()
    {
        elevatorTransform.position = Vector3.MoveTowards(elevatorTransform.position, goToTransform.position, speed * Time.deltaTime);
    }
}
