using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lockdown : MonoBehaviour
{
    public GameObject objectToEnable;
    public float MinimumTime;
    public float MaximumTime;
    public AudioClip Sound;

    void PlaySound()
    {
        if (Sound != null)
        {
            AudioSource.PlayClipAtPoint(Sound, Camera.main.transform.position);
        }
    }

    void Start()
    {
        float randomTime = Random.Range(MinimumTime, MaximumTime);
        Invoke("EnableObject", randomTime);
    }

    void EnableObject()
    {
        objectToEnable.SetActive(true);
    }
}
